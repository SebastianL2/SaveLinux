   #!/bin/bash
  


 for (( i=2; i<12; i++ ))

do
 notes=`awk 'NR== '$i Notas.csv`
 
   L1=` echo ${notes:10:3}`
   L2=` echo ${notes:14:3}`
   L3=` echo ${notes:18:3}`
   nota1=$(echo "scale=2;($L1*0.1)" | bc)
   nota2=$(echo "scale=2;($L2*0.3)" | bc)
   nota3=$(echo "scale=2;($L3*0.6)" | bc)
   def=$(echo "scale=2;($nota1+$nota2+$nota3)" | bc)
 
echo $def
if [[ $def > 2.95 ]]
then
   echo "$notes" "$def "  >> aprobados.txt
else

    echo "$notes"  "$def"  >> reprobados.txt
fi

done
   





